Ability Server
**************

Application Name:		Ability Server
Url:				http://www.code-crafters.com/abilitywebserver.html
Author:				Code-Crafters



Installation Instructions
*************************

Extract all the files into a single folder, then to run the application simply
double click on the exe file.



Setup / Upgrade Instructions
****************************

Visit...

http://www.code-crafters.com/abilitywebserver.html

for information.



Legal Notes
***********

Code-Crafters or any of its staff accept NO responsibility for any
damaged caused by this program or any of its files.
USE THIS PROGRAM AT YOUR OWN RISK!

This program can be distributed freely as the program is freeware, however, if the program is
to be printed onto CD or any other physical form, Code-Crafters must be
contacted and asked for their permission. Thank you


Contant Info
************

Email Address:	info@code-crafters.com